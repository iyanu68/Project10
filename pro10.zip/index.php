
        <?php
        
        include 'head.php';
        include 'home.php';

        ?>