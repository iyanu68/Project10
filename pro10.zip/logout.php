
<?php
// Perform any other logout-related actions here, if needed

// Redirect to the login page
header("Location: home.php");
exit();
?>